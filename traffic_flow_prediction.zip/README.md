# Traffic Flow Prediction for Smart Cities

## Objective
Analyze synthetic traffic data to forecast traffic conditions and suggest optimal routes.

## How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the project:
   ```bash
   python main.py
   ```

## Outputs
- Saved ML model (`artifacts/traffic_model.joblib`)
- Plots (`artifacts/fig_scatter.png`, `artifacts/fig_feature_importance.png`)
- PDF Report (`Traffic_Flow_Prediction_Report.pdf`)
